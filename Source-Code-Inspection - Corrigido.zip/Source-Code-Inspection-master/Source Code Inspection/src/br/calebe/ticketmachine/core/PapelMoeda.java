package br.calebe.ticketmachine.core;

/*
Matheus Guedes da Paixão - 32041586
Matheus Stefano Mendes - 32025238
Vitor Olivetti Ramos - 32023049
*/

/**
 *
 * @author Calebe de Paula Bianchini
 */
public class PapelMoeda {

    protected int valor;
    protected int quantidade;

    public PapelMoeda(int valor, int quantidade) {
        this.valor = valor;
        this.quantidade = quantidade;
    }

    public int getValor() { /* Inicialização: Falta de uma função setValor */
        return valor;
    }

    public int getQuantidade() { /* Inicialização: Falta de uma função setQuantidade */
        return quantidade;
    }
}
